import 'package:flutter/material.dart';

void main() {
  runApp(const WorkshopApp());
}

class WorkshopApp extends StatelessWidget {
  const WorkshopApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Workshop Kampus',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1D9E75)),
        useMaterial3: true,
      ),
      home: const WorkshopHomePage(),
    );
  }
}

// --- Model Data ---
class Workshop {
  final String judul;
  final String tanggal;
  final String lokasi;
  final int kuotaTerpakai;
  final int kuotaTotal;

  Workshop({
    required this.judul,
    required this.tanggal,
    required this.lokasi,
    required this.kuotaTerpakai,
    required this.kuotaTotal,
  });
}

// --- Data dummy ---
final List<Workshop> daftarWorkshop = [
  Workshop(
    judul: 'Flutter UI/UX Masterclass',
    tanggal: 'Sabtu, 17 Mei 2025',
    lokasi: 'Lab Komputer A, Gedung F',
    kuotaTerpakai: 24,
    kuotaTotal: 30,
  ),
  Workshop(
    judul: 'Machine Learning untuk Pemula',
    tanggal: 'Minggu, 25 Mei 2025',
    lokasi: 'Aula Rektorat Lt. 2',
    kuotaTerpakai: 10,
    kuotaTotal: 50,
  ),
];

// --- Halaman Utama ---
class WorkshopHomePage extends StatelessWidget {
  const WorkshopHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1D9E75),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Workshop Kampus',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '${daftarWorkshop.length} workshop tersedia',
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
      ),
      backgroundColor: const Color(0xFFF4F7F5),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: daftarWorkshop.length,
        itemBuilder: (context, index) {
          return WorkshopCard(workshop: daftarWorkshop[index]);
        },
      ),
    );
  }
}

// --- Widget Kartu Workshop ---
class WorkshopCard extends StatelessWidget {
  final Workshop workshop;

  const WorkshopCard({super.key, required this.workshop});

  @override
  Widget build(BuildContext context) {
    final sisaKuota = workshop.kuotaTotal - workshop.kuotaTerpakai;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      elevation: 1,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Aksen warna atas
          Container(
            height: 4,
            decoration: const BoxDecoration(
              color: Color(0xFF1D9E75),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(14),
                topRight: Radius.circular(14),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Judul Workshop
                Text(
                  workshop.judul,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1A1A1A),
                  ),
                ),
                const SizedBox(height: 10),

                // Tanggal
                Row(
                  children: [
                    const Icon(Icons.calendar_today,
                        size: 15, color: Color(0xFF1D9E75)),
                    const SizedBox(width: 6),
                    Text(
                      workshop.tanggal,
                      style: const TextStyle(
                          fontSize: 13, color: Colors.black54),
                    ),
                  ],
                ),
                const SizedBox(height: 6),

                // Lokasi
                Row(
                  children: [
                    const Icon(Icons.location_on,
                        size: 15, color: Color(0xFF1D9E75)),
                    const SizedBox(width: 6),
                    Text(
                      workshop.lokasi,
                      style: const TextStyle(
                          fontSize: 13, color: Colors.black54),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Footer: kuota + tombol daftar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Chip kuota
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE1F5EE),
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.people,
                              size: 14, color: Color(0xFF085041)),
                          const SizedBox(width: 4),
                          Text(
                            '${workshop.kuotaTerpakai} / ${workshop.kuotaTotal} kuota',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF085041),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Tombol Daftar
                    ElevatedButton(
                      onPressed: sisaKuota > 0
                          ? () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                      'Berhasil mendaftar: ${workshop.judul}'),
                                ),
                              );
                            }
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1D9E75),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        textStyle: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                      child: const Text('Daftar Sekarang'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}